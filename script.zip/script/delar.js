var cards = [
  "S1",
  "S2",
  "S3",
  "S4",
  "S5",
  "S6",
  "S7",
  "S8",
  "S9",
  "S10",
  "S11",
  "S12",
  "S13",
  "C1",
  "C2",
  "C3",
  "C4",
  "C5",
  "C6",
  "C7",
  "C8",
  "C9",
  "C10",
  "C11",
  "C12",
  "C13",
  "H1",
  "H2",
  "H3",
  "H4",
  "H5",
  "H6",
  "H7",
  "H8",
  "H9",
  "H10",
  "H11",
  "H12",
  "H13",
  "D1",
  "D2",
  "D3",
  "D4",
  "D5",
  "D6",
  "D7",
  "D8",
  "D9",
  "D10",
  "D11",
  "D12",
  "D13",
];

var card1 = null;
var card2 = null;
var card3 = null;
var card4 = null;
var card5 = null;
var card6 = null;
var card7 = null;
var card8 = null;
var card9 = null;
var card10 = null;
var card11 = null;
var card12 = null;
var card13 = null;
var card14 = null;
var card15 = null;
var card16 = null;
var card17 = null;
var card18 = null;
var card19 = null;
var card20 = null;
var card21 = null;
var card22 = null;
var card23 = null;
var card24 = null;
var card25 = null;

var pickCard = null;
var choosedCardElement = null;
var p1 = null;
var p2 = null;

var p1_scroll = 0;
var p2_scroll = 0;
var temp_score = 0;
var temp_player = "";
var latest = false;
var mode = 0;
var callback;

function shuffleCards(cards) {
  for (let i = cards.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [cards[i], cards[j]] = [cards[j], cards[i]];
  }
  return cards;
}

var shaffeledCards = shuffleCards(cards);
var playerOneCards = shaffeledCards.slice(0, 13);
var playerTwoCards = shaffeledCards.slice(13, 26);
card1 = shaffeledCards[44];

function popup() {
  let popup = document.getElementById("popup");
  popup.classList.add("open-popup");
}
function popup_choose_open() {
  let popup = document.getElementById("popup_choose");
  popup.classList.add("open-popup");
}

function popup_choose_close(status) {
  let p = document.getElementById("popup_choose");
  p.classList.remove("open-popup");
  if (status) {
    if (temp_player == "p1") {
      p1_scroll = p1_scroll + temp_score;
      if (mode == 0)
        document.getElementById("player1").innerHTML = "Score :" + p1_scroll;
    }
  }
  setTimeout(callback, 1500);
}

function mode_select(p) {
  mode = p;
  document.getElementById("two").addEventListener("click", two);
  document.getElementById("p_select").style.display = "none";
  document.getElementById("popup_nick_name1").classList.add("open-popup");
}

function delar(cards, element) {
  for (var i = cards.length - 1; i > 0; i--) {
    var card = document.createElement("div");
    card.className = "p-card";
    card.dataset.card = cards[i];
    card.addEventListener("click", chooseCard);
    var image = document.createElement("img");
    image.src = "./img/" + cards[i] + ".png";
    image.alt = cards[i];
    card.appendChild(image);
    element.appendChild(card);
  }
}

function chooseCard() {
  choosedCardElement = this;
  pickCard = this.dataset.card;
}

function turn(turn, off) {
  for (let i = 0; i < turn.length; i++) {
    turn[i].addEventListener("click", chooseCard);
  }
  for (let i = 0; i < off.length; i++) {
    off[i].removeEventListener("click", chooseCard);
  }
}

var preCard = null;
function bestCard(isLest, isCheck, ...checkCard) {
  let stb = {};
  let maxKey = playerTwoCards[0];
  let maxValue = -Infinity;
  playerTwoCards.forEach((card) => {
    let result = score(...checkCard, card);
    if (isCheck) {
      let preResult = score(...checkCard);
      if (check(preResult.name, result.name, preResult.score, result.score)) {
        stb[card] = result.score;
      }
    } else {
      stb[card] = result.score;
    }
  });
  for (const key in stb) {
    if (stb.hasOwnProperty(key)) {
      const value = stb[key];
      if (value > maxValue) {
        maxKey = key;
        maxValue = value;
      }
    }
  }
  if (maxKey == playerTwoCards[0]) {
    maxKey = playerTwoCards[1];
    if (preCard !== null) maxKey = preCard;
  }
  if (isLest) {
    document.getElementById(maxKey).remove();
    playerTwoCards = playerTwoCards.filter((item) => item !== maxKey);
    preCard = null;
  } else {
    preCard = maxKey;
  }
  return maxKey;
}

function two() {
  if (choosedCardElement) {
    card2 = pickCard;
    playerOneCards = playerOneCards.filter((item) => item !== pickCard);
    choosedCardElement.remove();
    document.getElementById(
      "two"
    ).innerHTML = `<img src="./img/${card2}.png" alt="${card2}">`;
    document.getElementById("two").removeEventListener("click", two);
    choosedCardElement = null;
    turn(
      document.getElementById("p2").children,
      document.getElementById("p1").children
    );
    let result = score(card1, card2);
    let scoreResult = result.score;
    callback = three;
    scoreName(scoreResult, "p1", result.name);
    document.getElementById("scoreNameai").innerHTML = "";
  }
}

function three() {
  card3 = bestCard(true, false, card2);
  document.getElementById(
    "three"
  ).innerHTML = `<img src="./img/${card3}.png" alt="${card3}">`;
  document.getElementById("four").addEventListener("click", four);
  turn(
    document.getElementById("p1").children,
    document.getElementById("p2").children
  );
  let result = score(card2, card3);
  let scoreResult = result.score;
  p2_scroll = p2_scroll + scoreResult;
  if (mode == 0)
    document.getElementById("player2").innerHTML = "Score :" + p2_scroll;
  scoreNameAI(result.name);
}

function four() {
  if (choosedCardElement) {
    card4 = pickCard;
    playerOneCards = playerOneCards.filter((item) => item !== pickCard);
    choosedCardElement.remove();
    document.getElementById(
      "four"
    ).innerHTML = `<img src="./img/${card4}.png" alt="${card4}">`;
    document.getElementById("four").removeEventListener("click", four);
    choosedCardElement = null;
    turn(
      document.getElementById("p2").children,
      document.getElementById("p1").children
    );
    let result = score(card3, card4);
    let result2 = score(card1, card4);
    let scoreResult = result.score;
    let scoreResult2 = result2.score;
    callback = five;
    let res = scoreName(
      scoreResult + scoreResult2,
      "p1",
      ...result.name,
      ...result2.name
    );
    if (res) setTimeout(five, 1500);
  }
  document.getElementById("scoreNameai").innerHTML = "";
}

function five() {
  card5 = bestCard(true, true, card3, card4);
  document.getElementById(
    "five"
  ).innerHTML = `<img src="./img/${card5}.png" alt="${card5}">`;
  document.getElementById("six").addEventListener("click", six);
  turn(
    document.getElementById("p1").children,
    document.getElementById("p2").children
  );
  let preResult = score(card3, card4);
  let result = score(card3, card4, card5);
  let scoreResult = result.score;
  let ScoreNamesList = [];
  if (check(preResult.name, result.name, preResult.score, result.score)) {
    p2_scroll = p2_scroll + scoreResult;
    ScoreNamesList = result.name;
  }
  if (mode == 0)
    document.getElementById("player2").innerHTML = "Score :" + p2_scroll;
  scoreNameAI(ScoreNamesList);
}

function six() {
  if (choosedCardElement) {
    card6 = pickCard;
    playerOneCards = playerOneCards.filter((item) => item !== pickCard);
    choosedCardElement.remove();
    document.getElementById(
      "six"
    ).innerHTML = `<img src="./img/${card6}.png" alt="${card6}">`;
    document.getElementById("six").removeEventListener("click", six);
    choosedCardElement = null;
    turn(
      document.getElementById("p2").children,
      document.getElementById("p1").children
    );
    let preResult = score(card1, card2);
    let result = score(card2, card6, card1);
    let result2 = score(card5, card6);
    let scoreResult = result.score;
    let scoreResult2 = result2.score;
    let ScoreNamesList = result2.name;
    if (check(preResult.name, result.name, preResult.score, result.score)) {
      ScoreNamesList = [...ScoreNamesList, ...result2.name];
    }
    callback = seven;
    let res = scoreName(scoreResult + scoreResult2, "p1", ScoreNamesList);
    if (res) setTimeout(seven, 1500);
  }
  document.getElementById("scoreNameai").innerHTML = "";
}

function seven() {
  card7 = bestCard(true, true, card5, card6);
  document.getElementById(
    "seven"
  ).innerHTML = `<img src="./img/${card7}.png" alt="${card7}">`;
  document.getElementById("eight").addEventListener("click", eight);
  turn(
    document.getElementById("p1").children,
    document.getElementById("p2").children
  );
  let preResult = score(card5, card6);
  let result = score(card5, card6, card7);
  let scoreResult = result.score;
  let ScoreNamesList = [];
  if (check(preResult.name, result.name, preResult.score, result.score)) {
    p2_scroll = p2_scroll + scoreResult;
    ScoreNamesList = result.name;
  }
  if (mode == 0)
    document.getElementById("player2").innerHTML = "Score :" + p2_scroll;
  scoreNameAI(ScoreNamesList);
}

function eight() {
  if (choosedCardElement) {
    card8 = pickCard;
    playerOneCards = playerOneCards.filter((item) => item !== pickCard);
    choosedCardElement.remove();
    document.getElementById(
      "eight"
    ).innerHTML = `<img src="./img/${card8}.png" alt="${card8}">`;
    document.getElementById("eight").removeEventListener("click", eight);
    choosedCardElement = null;
    turn(
      document.getElementById("p2").children,
      document.getElementById("p1").children
    );
    let result = score(card7, card8);
    let result2 = score(card1, card8, card4);
    let preResult = score(card1, card4);
    let scoreResult = result.score;
    let scoreResult2 = result2.score;
    let ScoreNamesList = result.name;
    if (check(preResult.name, result2.name, preResult.score, result2.score)) {
      ScoreNamesList = [...ScoreNamesList, ...result2.name];
    }
    callback = nine;
    let res = scoreName(scoreResult + scoreResult2, "p1", ScoreNamesList);
    if (res) setTimeout(nine, 1500);
  }
  document.getElementById("scoreNameai").innerHTML = "";
}

function nine() {
  card9 = bestCard(false, true, card7, card8);
  card9 = bestCard(true, true, card3, card2);
  document.getElementById(
    "nine"
  ).innerHTML = `<img src="./img/${card9}.png" alt="${card9}">`;
  document.getElementById("ten").addEventListener("click", ten);
  turn(
    document.getElementById("p1").children,
    document.getElementById("p2").children
  );
  let preResult = score(card7, card8);
  let preResult2 = score(card3, card2);
  let result = score(card7, card8, card9);
  let result2 = score(card9, card3, card2);
  let scoreResult = result.score;
  let scoreResult2 = result2.score;
  let ScoreNamesList = [];
  if (check(preResult.name, result.name, preResult.score, result.score)) {
    p2_scroll = p2_scroll + scoreResult;
    ScoreNamesList = result.name;
  }
  if (check(preResult2.name, result2.name, preResult2.score, result2.score)) {
    p2_scroll = p2_scroll + scoreResult2;
    ScoreNamesList = [...ScoreNamesList, ...result2.name];
  }
  if (mode == 0)
    document.getElementById("player2").innerHTML = "Score :" + p2_scroll;
  scoreNameAI(ScoreNamesList);
}

function ten() {
  if (choosedCardElement) {
    card10 = pickCard;
    playerOneCards = playerOneCards.filter((item) => item !== pickCard);
    choosedCardElement.remove();
    document.getElementById(
      "ten"
    ).innerHTML = `<img src="./img/${card10}.png" alt="${card10}">`;
    document.getElementById("ten").removeEventListener("click", ten);
    choosedCardElement = null;
    turn(
      document.getElementById("p2").children,
      document.getElementById("p1").children
    );
    let preResult = score(card7, card8, card9);
    let result = score(card10, card7, card8, card9);
    let scoreResult = result.score;
    let ScoreNamesList = [];
    if (check(preResult.name, result.name, preResult.score, result.score)) {
      ScoreNamesList = result.name;
    }
    callback = eleven;
    let res = scoreName(scoreResult, "p1", ScoreNamesList);
    if (res) setTimeout(eleven, 1500);
  }
  document.getElementById("scoreNameai").innerHTML = "";
}

function eleven() {
  card11 = bestCard(false, true, card10);
  card11 = bestCard(true, true, card1, card2, card6);
  document.getElementById(
    "eleven"
  ).innerHTML = `<img src="./img/${card11}.png" alt="${card11}">`;
  document.getElementById("twelve").addEventListener("click", twelve);
  turn(
    document.getElementById("p1").children,
    document.getElementById("p2").children
  );
  let result = score(card10, card11);
  let result2 = score(card1, card11, card2, card6);
  let preResult = score(card1, card2, card6);
  let scoreResult = result.score;
  let scoreResult2 = result2.score;
  p2_scroll = p2_scroll + scoreResult;
  let ScoreNamesList = result.name;
  if (check(preResult.name, result2.name, preResult.score, result2.score)) {
    p2_scroll = p2_scroll + scoreResult2;
    ScoreNamesList = [...ScoreNamesList, ...result2.name];
  }
  if (mode == 0)
    document.getElementById("player2").innerHTML = "Score :" + p2_scroll;
  scoreNameAI(ScoreNamesList);
}

function twelve() {
  if (choosedCardElement) {
    card12 = pickCard;
    playerOneCards = playerOneCards.filter((item) => item !== pickCard);
    choosedCardElement.remove();
    document.getElementById(
      "twelve"
    ).innerHTML = `<img src="./img/${card12}.png" alt="${card12}">`;
    document.getElementById("twelve").removeEventListener("click", twelve);
    choosedCardElement = null;
    turn(
      document.getElementById("p2").children,
      document.getElementById("p1").children
    );
    let result = score(card11, card12, card10);
    let result2 = score(card3, card4, card5, card12);
    let preResult = score(card10, card11);
    let preResult2 = score(card3, card4, card5);
    let scoreResult = result.score;
    let scoreResult2 = result2.score;
    let ScoreNamesList = [];
    if (check(preResult.name, result.name, preResult.score, result.score)) {
      ScoreNamesList = result.name;
    }
    if (check(preResult2.name, result2.name, preResult2.score, result2.score)) {
      ScoreNamesList = [...ScoreNamesList, ...result2.name];
    }
    callback = thirteen;
    let res = scoreName(scoreResult + scoreResult2, "p1", ScoreNamesList);
    if (res) setTimeout(thirteen, 1500);
  }
  document.getElementById("scoreNameai").innerHTML = "";
}

function thirteen() {
  card13 = bestCard(true, true, card10, card11, card12);
  document.getElementById(
    "thirteen"
  ).innerHTML = `<img src="./img/${card13}.png" alt="${card13}">`;
  document.getElementById("fourteen").addEventListener("click", fourteen);
  turn(
    document.getElementById("p1").children,
    document.getElementById("p2").children
  );
  let result = score(card11, card12, card10, card13);
  let preResult = score(card10, card11, card12);
  let scoreResult = result.score;
  let ScoreNamesList = [];
  if (check(preResult.name, result.name, preResult.score, result.score)) {
    p2_scroll = p2_scroll + scoreResult;
    ScoreNamesList = result.name;
  }
  if (mode == 0)
    document.getElementById("player2").innerHTML = "Score :" + p2_scroll;
  scoreNameAI(ScoreNamesList);
}

function fourteen() {
  if (choosedCardElement) {
    card14 = pickCard;
    playerOneCards = playerOneCards.filter((item) => item !== pickCard);
    choosedCardElement.remove();
    document.getElementById(
      "fourteen"
    ).innerHTML = `<img src="./img/${card14}.png" alt="${card14}">`;
    document.getElementById("fourteen").removeEventListener("click", fourteen);
    choosedCardElement = null;
    turn(
      document.getElementById("p2").children,
      document.getElementById("p1").children
    );
    let result = score(card13, card14);
    let result2 = score(card2, card3, card9, card14);
    let preResult = score(card2, card3, card9);
    let scoreResult = result.score;
    let scoreResult2 = result2.score;
    let ScoreNamesList = result.name;
    if (check(preResult.name, result2.name, preResult.score, result2.score)) {
      ScoreNamesList = [...ScoreNamesList, ...result2.name];
    }
    callback = fifteen;
    let res = scoreName(scoreResult + scoreResult2, "p1", ScoreNamesList);
    if (res) setTimeout(fifteen, 1500);
  }
  document.getElementById("scoreNameai").innerHTML = "";
}

function fifteen() {
  card15 = bestCard(false, true, card13, card14);
  card15 = bestCard(true, true, card1, card4, card8);
  document.getElementById(
    "fifteen"
  ).innerHTML = `<img src="./img/${card15}.png" alt="${card15}">`;
  document.getElementById("sixteen").addEventListener("click", sixteen);
  turn(
    document.getElementById("p1").children,
    document.getElementById("p2").children
  );
  let result = score(card13, card14, card15);
  let result2 = score(card1, card4, card8, card15);
  let preResult = score(card13, card14);
  let preResult2 = score(card1, card4, card8);
  let scoreResult = result.score;
  let scoreResult2 = result2.score;
  let ScoreNamesList = [];
  if (check(preResult.name, result.name, preResult.score, result.score)) {
    p2_scroll = p2_scroll + scoreResult;
    ScoreNamesList = result.name;
  }
  if (check(preResult2.name, result2.name, preResult2.score, result2.score)) {
    p2_scroll = p2_scroll + scoreResult2;
    ScoreNamesList = [...ScoreNamesList, ...result2.name];
  }
  if (mode == 0)
    document.getElementById("player2").innerHTML = "Score :" + p2_scroll;
  scoreNameAI(ScoreNamesList);
}

function sixteen() {
  if (choosedCardElement) {
    card16 = pickCard;
    playerOneCards = playerOneCards.filter((item) => item !== pickCard);
    choosedCardElement.remove();
    document.getElementById(
      "sixteen"
    ).innerHTML = `<img src="./img/${card16}.png" alt="${card16}">`;
    document.getElementById("sixteen").removeEventListener("click", sixteen);
    choosedCardElement = null;
    turn(
      document.getElementById("p2").children,
      document.getElementById("p1").children
    );
    let result = score(card13, card14, card15, card16);
    let result2 = score(card5, card6, card7, card16);
    let preResult = score(card13, card14, card15);
    let preResult2 = score(card5, card6, card7);
    let scoreResult = result.score;
    let scoreResult2 = result2.score;
    let ScoreNamesList = [];
    if (check(preResult.name, result.name, preResult.score, result.score)) {
      ScoreNamesList = result.name;
    }
    if (check(preResult2.name, result2.name, preResult2.score, result2.score)) {
      ScoreNamesList = [...ScoreNamesList, ...result2.name];
    }
    callback = seventeen;
    let res = scoreName(scoreResult + scoreResult2, "p1", ScoreNamesList);
    if (res) setTimeout(seventeen, 1500);
  }
  document.getElementById("scoreNameai").innerHTML = "";
}

function seventeen() {
  card17 = bestCard(true, true, card13, card14, card15, card16);
  document.getElementById(
    "seventeen"
  ).innerHTML = `<img src="./img/${card17}.png" alt="${card17}">`;
  document.getElementById("eighteen").addEventListener("click", eighteen);
  turn(
    document.getElementById("p1").children,
    document.getElementById("p2").children
  );
  let result = score(card13, card14, card15, card16, card17);
  let preResult = score(card13, card14, card15, card16);
  let scoreResult = result.score;
  let ScoreNamesList = [];
  if (check(preResult.name, result.name, preResult.score, result.score)) {
    p2_scroll = p2_scroll + scoreResult;
    ScoreNamesList = result.name;
  }
  if (mode == 0)
    document.getElementById("player2").innerHTML = "Score :" + p2_scroll;
  scoreNameAI(ScoreNamesList);
}

function eighteen() {
  if (choosedCardElement) {
    card18 = pickCard;
    playerOneCards = playerOneCards.filter((item) => item !== pickCard);
    choosedCardElement.remove();
    document.getElementById(
      "eighteen"
    ).innerHTML = `<img src="./img/${card18}.png" alt="${card18}">`;
    document.getElementById("eighteen").removeEventListener("click", eighteen);
    choosedCardElement = null;
    turn(
      document.getElementById("p2").children,
      document.getElementById("p1").children
    );
    let result = score(card17, card18);
    let result2 = score(card18, card3, card4, card5, card12);
    let preResult = score(card3, card4, card5, card12);
    let scoreResult = result.score;
    let scoreResult2 = result2.score;
    let ScoreNamesList = result.name;
    if (check(preResult.name, result2.name, preResult.score, result2.score)) {
      ScoreNamesList = [...ScoreNamesList, ...result2.name];
    }
    callback = nineteen;
    let res = scoreName(scoreResult + scoreResult2, "p1", ScoreNamesList);
    if (res) setTimeout(nineteen, 1500);
  }
  document.getElementById("scoreNameai").innerHTML = "";
}

function nineteen() {
  card19 = bestCard(false, true, card17, card18);
  card19 = bestCard(true, true, card6, card1, card2, card11);
  document.getElementById(
    "nineteen"
  ).innerHTML = `<img src="./img/${card19}.png" alt="${card19}">`;
  document.getElementById("twenty").addEventListener("click", twenty);
  turn(
    document.getElementById("p1").children,
    document.getElementById("p2").children
  );
  let result = score(card17, card18, card19);
  let result2 = score(card6, card1, card2, card11, card19);
  let preResult = score(card17, card18);
  let preResult2 = score(card1, card2, card6, card11);
  let scoreResult = result.score;
  let scoreResult2 = result2.score;
  let ScoreNamesList = [];
  if (check(preResult.name, result.name, preResult.score, result.score)) {
    p2_scroll = p2_scroll + scoreResult;
    ScoreNamesList = result.name;
  }
  if (check(preResult2.name, result2.name, preResult2.score, result2.score)) {
    p2_scroll = p2_scroll + scoreResult2;
    ScoreNamesList = [...ScoreNamesList, ...result2.name];
  }
  if (mode == 0)
    document.getElementById("player2").innerHTML = "Score :" + p2_scroll;
  scoreNameAI(ScoreNamesList);
}

function twenty() {
  if (choosedCardElement) {
    card20 = pickCard;
    playerOneCards = playerOneCards.filter((item) => item !== pickCard);
    choosedCardElement.remove();
    document.getElementById(
      "twenty"
    ).innerHTML = `<img src="./img/${card20}.png" alt="${card20}">`;
    document.getElementById("twenty").removeEventListener("click", twenty);
    choosedCardElement = null;
    turn(
      document.getElementById("p2").children,
      document.getElementById("p1").children
    );
    let result = score(card17, card18, card19, card20);
    let result2 = score(card7, card8, card9, card10, card20);
    let preResult = score(card17, card18, card19);
    let preResult2 = score(card7, card8, card9, card10);
    let scoreResult = result.score;
    let scoreResult2 = result2.score;
    let ScoreNamesList = [];
    if (check(preResult.name, result.name, preResult.score, result.score)) {
      ScoreNamesList = result.name;
    }
    if (check(preResult2.name, result2.name, preResult2.score, result2.score)) {
      ScoreNamesList = [...ScoreNamesList, ...result2.name];
    }
    callback = twentyone;
    let res = scoreName(scoreResult + scoreResult2, "p1", ScoreNamesList);
    if (res) setTimeout(twentyone, 1500);
  }
  document.getElementById("scoreNameai").innerHTML = "";
}

function twentyone() {
  card21 = bestCard(true, true, card17, card18, card19, card20);
  document.getElementById(
    "twentyone"
  ).innerHTML = `<img src="./img/${card21}.png" alt="${card21}">`;
  document.getElementById("twentytwo").addEventListener("click", twentytwo);
  turn(
    document.getElementById("p1").children,
    document.getElementById("p2").children
  );
  let result = score(card17, card18, card19, card20, card21);
  let preResult = score(card17, card18, card19, card20);
  let scoreResult = result.score;
  let ScoreNamesList = [];
  if (check(preResult.name, result.name, preResult.score, result.score)) {
    p2_scroll = p2_scroll + scoreResult;
    ScoreNamesList = result.name;
  }
  if (mode == 0)
    document.getElementById("player2").innerHTML = "Score :" + p2_scroll;
  scoreNameAI(ScoreNamesList);
}

function twentytwo() {
  if (choosedCardElement) {
    card22 = pickCard;
    playerOneCards = playerOneCards.filter((item) => item !== pickCard);
    choosedCardElement.remove();
    document.getElementById(
      "twentytwo"
    ).innerHTML = `<img src="./img/${card22}.png" alt="${card22}">`;
    document
      .getElementById("twentytwo")
      .removeEventListener("click", twentytwo);
    choosedCardElement = null;
    turn(
      document.getElementById("p2").children,
      document.getElementById("p1").children
    );
    let result = score(card21, card22);
    let result2 = score(card5, card6, card7, card16, card22);
    let preResult = score(card5, card6, card7, card16);
    let scoreResult = result.score;
    let scoreResult2 = result2.score;
    let ScoreNamesList = result.name;
    if (check(preResult.name, result2.name, preResult.score, result2.score)) {
      ScoreNamesList = [...ScoreNamesList, ...result2.name];
    }
    callback = twentythree;
    let res = scoreName(scoreResult + scoreResult2, "p1", ScoreNamesList);
    if (res) setTimeout(twentythree, 1500);
  }
  document.getElementById("scoreNameai").innerHTML = "";
}

function twentythree() {
  card23 = bestCard(false, true, card21, card22);
  card23 = bestCard(true, true, card1, card4, card8, card15);
  document.getElementById(
    "twentythree"
  ).innerHTML = `<img src="./img/${card7}.png" alt="${card23}">`;
  document.getElementById("twentyfour").addEventListener("click", twentyfour);
  turn(
    document.getElementById("p1").children,
    document.getElementById("p2").children
  );
  let result = score(card21, card22, card23);
  let result2 = score(card1, card4, card8, card15, card23);
  let preResult = score(card21, card22);
  let preResult2 = score(card1, card4, card8, card15);
  let scoreResult = result.score;
  let scoreResult2 = result2.score;
  let ScoreNamesList = [];
  if (check(preResult.name, result.name, preResult.score, result.score)) {
    p2_scroll = p2_scroll + scoreResult;
    ScoreNamesList = result.name;
  }
  if (check(preResult2.name, result2.name, preResult2.score, result2.score)) {
    p2_scroll = p2_scroll + scoreResult2;
    ScoreNamesList = [...ScoreNamesList, ...result2.name];
  }
  if (mode == 0)
    document.getElementById("player2").innerHTML = "Score :" + p2_scroll;
  scoreNameAI(ScoreNamesList);
}

function twentyfour() {
  if (choosedCardElement) {
    card24 = pickCard;
    playerOneCards = playerOneCards.filter((item) => item !== pickCard);
    choosedCardElement.remove();
    document.getElementById(
      "twentyfour"
    ).innerHTML = `<img src="./img/${card24}.png" alt="${card24}">`;
    document
      .getElementById("twentyfour")
      .removeEventListener("click", twentyfour);
    choosedCardElement = null;
    turn(
      document.getElementById("p2").children,
      document.getElementById("p1").children
    );
    let result = score(card21, card22, card23, card24);
    let result2 = score(card2, card3, card9, card14, card24);
    let preResult = score(card21, card22, card23);
    let preResult2 = score(card2, card3, card9, card14);
    let scoreResult = result.score;
    let scoreResult2 = result2.score;
    let ScoreNamesList = [];
    if (check(preResult.name, result.name, preResult.score, result.score)) {
      ScoreNamesList = result.name;
    }
    if (check(preResult2.name, result2.name, preResult2.score, result2.score)) {
      ScoreNamesList = [...ScoreNamesList, ...result2.name];
    }
    callback = twentyfive;
    let res = scoreName(scoreResult + scoreResult2, "p1", ScoreNamesList);
    if (res) setTimeout(twentyfive, 1500);
  }
  document.getElementById("scoreNameai").innerHTML = "";
}

function twentyfive() {
  card25 = bestCard(false, true, card21, card22, card23, card24);
  card25 = bestCard(true, true, card10, card11, card12, card13);
  document.getElementById(
    "twentyfive"
  ).innerHTML = `<img src="./img/${card25}.png" alt="${card25}">`;
  document
    .getElementById("twentyfive")
    .removeEventListener("click", twentyfive);
  turn(
    document.getElementById("p1").children,
    document.getElementById("p2").children
  );
  let result = score(card21, card22, card23, card24, card25);
  let result2 = score(card10, card11, card12, card13, card25);
  let preResult = score(card21, card22, card23, card24);
  let preResult2 = score(card10, card11, card12, card13);
  let scoreResult = result.score;
  let scoreResult2 = result2.score;
  let ScoreNamesList = [];
  if (check(preResult.name, result.name, preResult.score, result.score)) {
    p2_scroll = p2_scroll + scoreResult;
    ScoreNamesList = result.name;
  }
  if (check(preResult2.name, result2.name, preResult2.score, result2.score)) {
    p2_scroll = p2_scroll + scoreResult2;
    ScoreNamesList = [...ScoreNamesList, ...result2.name];
  }
  latest = true;
  scoreNameAI(ScoreNamesList);
  if (latest) {
    document.getElementById("p1").innerHTML = p1_scroll;
    document.getElementById("p2").innerHTML = p2_scroll;
    document.getElementById("p1_final").innerHTML =
      player_1_name + " : " + p1_scroll;
    document.getElementById("p2_final").innerHTML =
      Player_2_name + " : " + p2_scroll;
    let winner = document.getElementById("winner");
    if (p1_scroll > p2_scroll) {
      winner.innerHTML = player_1_name;
    } else {
      winner.innerHTML = Player_2_name;
    }
    popup();
  }
}
