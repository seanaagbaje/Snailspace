function aiCard(cards,element){
    for(var i= cards.length-1;i>0;i--){
        var card = document.createElement('div');
        card.id=cards[i];
        card.className = 'p-card';
        card.dataset.card = cards[i];
        card.addEventListener('click',chooseCard);
        var image = document.createElement('img');
        image.src = './img/backcard.png';
        // image.src = './img/'+cards[i]+'.png';
        image.alt = cards[i];
        card.appendChild(image);
        element.appendChild(card);
    }
}
aiCard(playerOneCards,document.getElementById('p1'));
delar(playerTwoCards,document.getElementById('p2'));


document.getElementById('one').innerHTML = `<img src="./img/${card1}.png" alt="${card1}">`;


turn(document.getElementById('p1').children,document.getElementById('p2').children);  
