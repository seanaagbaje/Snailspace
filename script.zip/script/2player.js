delar(playerOneCards, document.getElementById("p1"));
delar(playerTwoCards, document.getElementById("p2"));

document.getElementById(
  "one"
).innerHTML = `<img src="./img/${card1}.png" alt="${card1}">`;

turn(
  document.getElementById("p1").children,
  document.getElementById("p2").children
);

document.getElementById("yes").addEventListener("click", () => {
  document.getElementById("scoreName").innerText = "";
  popup_choose_close(true);
});

document.getElementById("no").addEventListener("click", () => {
  document.getElementById("scoreName").innerText = "";
  popup_choose_close(false);
});

document.getElementById("choice_nick_name1").addEventListener("click", () => {
  let name = document.getElementById("nickname1").value;
  if (name != "") {
    player_1_name = name;
    document.getElementById("delar_name").innerText = player_1_name;
  }
  document.getElementById("popup_nick_name1").style.display = "none";
  document.getElementById("popup_nick_name2").classList.add("open-popup");
});

document.getElementById("choice_nick_name2").addEventListener("click", () => {
  let name = document.getElementById("nickname2").value;
  if (name != "") {
    Player_2_name = name;
    document.getElementById("non_delar_name").innerText = Player_2_name;
  }
  document.getElementById("popup_nick_name2").style.display = "none";
});
